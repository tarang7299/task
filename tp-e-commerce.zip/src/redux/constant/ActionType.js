export const ActionTypes = {
  AUTH: "AUTH",

  SET_ITEM_TO_CART: "SET_ITEM_TO_CART",
  SET_ITEM_TO_WISHLIST: "SET_ITEM_TO_WISHLIST",
};
